<?php
date_default_timezone_set('Asia/Jakarta');
@system("clear");

$star = "7000";
$max = "8000";
$key = "fc9f101c87fed31e22bc896af4183fb4";
$senxx = "doge";

$urutann = file_get_contents("$senxx");
$yelahh = explode("\n",$urutann);
while(true){
for($x=$star;$x<=$max,$x<count($yelahh);$x++){
$yeah = explode("|",$yelahh[$x]);
$crot = $yeah[0];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://digitask.ru/notimer/faucet.php?address=".$crot."&g-recaptcha-response=03AERD8XpOxHGMRuvpjcRH-JoQhJX5B82EQLYWjLOFDV19RUtF80W7TpkVRAW89jtJS8oaCiqiFGf8Nyj0x3kc_A0IdaG12AdEO2qh--6B4zSwdEobvj2FzUP2grK30ypR4tfofO7tUhTk8ixGN-l8rXPNkUGTu-u8yFRoc4v5DcQlyBJPdhobeHFOuxuRaqXb8d4FQ5cIzV17u4iiUkRy8s2lKwi5QKjHVBGxmO9bpK8zrY70S29rsXsGs3B0J6QktdiCzqcGrKhJNdAr-OWj7VE98vZqa2O0V2XHmqcdbxPV783UwXX3ZO95aqHulG-JLj_goWTGDzfNj3QZe_a-IPn8r73vgZx2Km5Bd2UfZq3yCMko4BYHHGecFmh0ug-dgH11J5tgW7oS&wallet=&currency=DOGE&key=".$key);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host: digitask.ru" , "upgrade-insecure-requests: 1" , "user-agent: Mozilla/5.0 (Linux; Android 9; Redmi 4 Build/PQ3B.190801.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/76.0.3809.111 Mobile Safari/537.36" , "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3" , "referer: https://digitads.club/notimer/faucet.php?address=".$crot."&g-recaptcha-response=03AERD8XpOxHGMRuvpjcRH-JoQhJX5B82EQLYWjLOFDV19RUtF80W7TpkVRAW89jtJS8oaCiqiFGf8Nyj0x3kc_A0IdaG12AdEO2qh--6B4zSwdEobvj2FzUP2grK30ypR4tfofO7tUhTk8ixGN-l8rXPNkUGTu-u8yFRoc4v5DcQlyBJPdhobeHFOuxuRaqXb8d4FQ5cIzV17u4iiUkRy8s2lKwi5QKjHVBGxmO9bpK8zrY70S29rsXsGs3B0J6QktdiCzqcGrKhJNdAr-OWj7VE98vZqa2O0V2XHmqcdbxPV783UwXX3ZO95aqHulG-JLj_goWTGDzfNj3QZe_a-IPn8r73vgZx2Km5Bd2UfZq3yCMko4BYHHGecFmh0ug-dgH11J5tgW7oS&wallet=&currency=DOGE&key=".$key."" , "accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7" , "cookie: valet_adress=".$crot."" , "cookie: ft=2447322960" , "cookie: bidswitch_last_time=1583322723789" , ""));
$mbot = curl_exec($ch);
curl_close($ch);
$bale = explode('<div class="alert alert-success">', $mbot);
$bale2 = explode('<a target=',$bale[1]);
$xc = $bale2[0];
//echo $mbot." \n";
//KANXCK
if($xc == true){
echo " \033[1;32m".$x." \033[1;33m[\033[1;35m".date('H:i:s')."\033[1;33m] \e[0m# \033[1;36m".$xc."your account\n";
}
if($x == "$max"){
break; 
     }
   }
sleep(rand(1,3));
}
