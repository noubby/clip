<?php
@system(clear);
exec('rm -rf xx');
$hh = array("Host: microwallet.co" , "user-agent: Mozilla/5.0 (Linux; Android 9; Redmi 4 Build/PQ3B.190801.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/76.0.3809.111 Mobile Safari/537.36" , "accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7");

$email = "noubbychannel@yahoo.com";
$pass = "pertanian";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://microwallet.co/act");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, $hh);
curl_setopt($ch, CURLOPT_COOKIEJAR, "xx");
curl_setopt($ch, CURLOPT_COOKIEFILE, "xx");
$mbot = curl_exec($ch);
curl_close($ch);
$bale = explode('<input type="hidden" name="_token" value="', $mbot);
$bale2 = explode('">',$bale[1]);
$xc = $bale2[0];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://microwallet.co/act");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "POST");
curl_setopt($ch, CURLOPT_HTTPHEADER, $hh);
curl_setopt($ch, CURLOPT_POSTFIELDS,  "_token=".$xc."&email=".$email."&password=".$pass);
curl_setopt($ch, CURLOPT_COOKIEJAR, "xx");
curl_setopt($ch, CURLOPT_COOKIEFILE, "xx");
$mbot = curl_exec($ch);
curl_close($ch);
$senxx = "doge";
$urutann = file_get_contents("$senxx");
$yelahh = explode("\n",$urutann);

for($x=1958;$x<count($yelahh);$x++){
$yeah = explode("|",$yelahh[$x]);
$crot = $yeah[0];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://microwallet.co/addresses/create");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, $hh);
curl_setopt($ch, CURLOPT_COOKIEJAR, "xx");
curl_setopt($ch, CURLOPT_COOKIEFILE, "xx");
$mbot = curl_exec($ch);
curl_close($ch);
$bale = explode('<input type="hidden" name="_token" value="', $mbot);
$bale2 = explode('">',$bale[1]);
$xcc = $bale2[0];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://microwallet.co/addresses/store");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "POST");
curl_setopt($ch, CURLOPT_HTTPHEADER, $hh);
curl_setopt($ch, CURLOPT_POSTFIELDS,  "_token=".$xcc."&label=&currency_id=3&address=".$crot);
curl_setopt($ch, CURLOPT_COOKIEJAR, "xx");
curl_setopt($ch, CURLOPT_COOKIEFILE, "xx");
$mbot = curl_exec($ch);
curl_close($ch);

/*for($x=1;$x<=28;$x++){
for($xx=1;$xx<=15;$xx++){
*/
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://microwallet.co/addresses/ajax?draw=1&columns%5B0%5D%5Bdata%5D=&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true&columns%5B0%5D%5Borderable%5D=false&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=false&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B2%5D%5Bdata%5D=&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=true&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B3%5D%5Bdata%5D=&columns%5B3%5D%5Bname%5D=&columns%5B3%5D%5Bsearchable%5D=true&columns%5B3%5D%5Borderable%5D=false&columns%5B3%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B3%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=2&order%5B0%5D%5Bdir%5D=desc&start=0&length=15&search%5Bvalue%5D=&search%5Bregex%5D=false&_=1582765528896");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, $hh);
curl_setopt($ch, CURLOPT_COOKIEJAR, "xx");
curl_setopt($ch, CURLOPT_COOKIEFILE, "xx");
$mbot = curl_exec($ch);
curl_close($ch);
$bale = explode('address":"', $mbot);
$bale2 = explode('",',$bale[1]);
$xc = $bale2[0];
$sr = json_decode($mbot, true);
echo "\033[1;32m ".$xc." \033[1;35m<=>";
$toket =  $xc."\n";
		$fh = fopen("tuyol", "a");
		fwrite($fh, $toket);
		fclose($fh);
echo " \033[1;36m".$sr["recordsTotal"]."\n";
/*if($sr["recordsTotal"] == "700") {
	exit();
echo " \033[1;32m".$xx." \033[1;36m<=> ";
echo "\033[1;35m".$xc."\n";
$toket =  $xc."\n";
		$fh = fopen("utm", "a");
		fwrite($fh, $toket);
		fclose($fh);
	}*/
	
//echo "\033[1;36m".$mbot."\n";
}