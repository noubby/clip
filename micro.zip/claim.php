<?php
date_default_timezone_set('Asia/Jakarta');
@system("clear");
exec('rm -rf ck');
    $senxx = "d";
$urutann = file_get_contents("tuyol");
$yelahh = explode("\n",$urutann);
while(true){
for($x=0;$x<count($yelahh);$x++){
$yeah = explode("|",$yelahh[$x]);
$crot = $yeah[0];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://digitads.club/notimer/faucet.php?address=".$crot."&g-recaptcha-response=03AERD8Xovw-9Qyq47J_LedpMxr3k6hOrTRVlqC_RGqPgcfrCq6Q7bV-it4I9zwTyC4UqeGZQ-ei-G5xQPrfQabZE2RunC8XY3sjDoSPiwGwLZJUrbB2rCAaDi0iWAAzzDXcWA9MBOKgaDFBaThc4eVwLERtHsizifRgkpNjuHR5DKwIPV7SXd-oRhFqOtaPdqO7nzxpMPoQCtU8YORCJ6YDuMAetZ6_wwULZ4YlzHCfRgIW5zfs8TTEni6zTEdNnwtnOQPBLmtsEdlzxzWn4SaszXu-8Rn4B-MG57U8aurCAM5MWXf999YcRiXu7H5OiQ07iH74GYCouLxkobbF-KegTnv8OgDiWfvFMpS7SX93WepvDZRPi7AR6j_n5fpdmMGOI8w9vB90gzCwi25tf1ZyjUS_rD-39l3g&wallet=&currency=DOGE&key=2ece896d842b574f017f2d0f8ddd1699");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host: digitads.club" , "upgrade-insecure-requests: 1" , "user-agent: Mozilla/5.0 (Linux; Android 9; Redmi 4 Build/PQ3B.190801.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/76.0.3809.111 Mobile Safari/537.36" , "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3" , "referer: https://digitads.club/notimer/faucet.php?address=".$crot."&g-recaptcha-response=03AERD8Xovw-9Qyq47J_LedpMxr3k6hOrTRVlqC_RGqPgcfrCq6Q7bV-it4I9zwTyC4UqeGZQ-ei-G5xQPrfQabZE2RunC8XY3sjDoSPiwGwLZJUrbB2rCAaDi0iWAAzzDXcWA9MBOKgaDFBaThc4eVwLERtHsizifRgkpNjuHR5DKwIPV7SXd-oRhFqOtaPdqO7nzxpMPoQCtU8YORCJ6YDuMAetZ6_wwULZ4YlzHCfRgIW5zfs8TTEni6zTEdNnwtnOQPBLmtsEdlzxzWn4SaszXu-8Rn4B-MG57U8aurCAM5MWXf999YcRiXu7H5OiQ07iH74GYCouLxkobbF-KegTnv8OgDiWfvFMpS7SX93WepvDZRPi7AR6j_n5fpdmMGOI8w9vB90gzCwi25tf1ZyjUS_rD-39l3g&wallet=&currency=DOGE&key=2ece896d842b574f017f2d0f8ddd1699" , "accept-encoding: gzip, deflate" , "accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7" , "cookie: valet_adress=".$crot."" , "cookie: ft=2447332221
cookie: valet_adress=D8xk9dfuBA9fkCYogVn2uaaggbXiQ5BtmB
cookie: bidswitch_last_time=1583122924178
cookie: _ym_uid=1583122927606134289
cookie: _ym_d=1583122927
cookie: rekmob_props_611559=%7B%22date%22%3A1583125292927%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A3%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A728%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22crt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%2271a52963ea75472aa8ade9200ed38044%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A90%2C%22region_id%22%3A611559%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583125365656%7D
cookie: rekmob_props_611586=%7B%22date%22%3A1583124766134%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A1%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A300%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22crt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%22993d1d3f99e449e789be5421ade92a15%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A250%2C%22region_id%22%3A611586%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583125365899%7D
cookie: rekmob_props_611558=%7B%22date%22%3A1583125108767%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A1%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A300%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22crt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%22c7e54a86a1b249718fbe9cfbaf380c75%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A250%2C%22region_id%22%3A611558%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583125365926%7D
cookie: rekmob_props_611587=%7B%22date%22%3A1583125348446%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A23%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A160%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22crt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%2208d43270bf444e019e416519bdf75d00%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A600%2C%22region_id%22%3A611587%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583125365947%7D
cookie: rekmob_props_611585=%7B%22date%22%3A1583124766007%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A1%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A300%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22crt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%22b0b6168b728649f7ab1e18b3cf2643c9%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A250%2C%22region_id%22%3A611585%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583125365953%7D
cookie: cto_bundle=hRDjw19IeVBxQjlwSU1TajFaSXJxa1NDcERNRWJTVU15UmRxUHE0UEs4ME4lMkJUa210WkpmNlRlTElPeEgxS21GZUE4S0lUeEFmRGRHRHg1Wll2R3glMkYyd25GdW9kUnRhWGRoUTJJS2NFZFcyQUM2cFNqTVZLbGQ4b00xTk41JTJCdmZBR000RA"));
curl_setopt($ch, CURLOPT_COOKIEJAR, "ck");
curl_setopt($ch, CURLOPT_COOKIEFILE, "ck");
$mbot = curl_exec($ch);
curl_close($ch);
$bale = explode('<div class="alert alert-success">', $mbot);
$bale2 = explode('<a target=',$bale[1]);
$xc = $bale2[0];
//KANXCK
if($xc == true){
echo " \033[1;33m[\033[1;35m".date('H:i:s')."\033[1;33m] \e[0m# \033[1;36m".$xc."your account\n";
}
}
}