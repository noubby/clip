<?php
date_default_timezone_set('Asia/Jakarta');
@system("clear");

$star = "4001";
$max = "5000";
$key = "ec9076a9d7b9f98d83633ef9e6fcd7da";
$senxx = "tuyol";

$urutann = file_get_contents("$senxx");
$yelahh = explode("\n",$urutann);
while(true){
for($x=$star;$x<=$max,$x<count($yelahh);$x++){
$yeah = explode("|",$yelahh[$x]);
$crot = $yeah[0];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://digitask.ru/notimer/faucet.php?address=".$crot."&g-recaptcha-response=03AERD8XppO9uNarViHMoKS38zi2rwNzthBrLp81JPKjwQNixzdIwmeVU-c6m-Rhp6oNKPzuvXI64tJjXDjm3Im_fx7sMnwx2s26wkI32YjmKWxHRRaWed3bCC6HffqyML1F3uhxiRCvPtLHkKqJ8ObLn3v4PV5_CAarEhaD5O4NC_1dcN5KurJgHLyc_E7INhsMpwRBO_LIIUvkmwmyKxBi_F8PI4godvyk16Hg22BiRQZak2jJz4hO75RsAW45cQKgVL5yu8woAx7nvhfvGjUfK5f9NlF7OhnboACR1mJmVeOF0rRsshLCng2GqF1yqUUgx8a88fLMSpe16SvznWSmkRnxKBrnWd9JFEC6MjXdQ4_Q2ytfY6KnGb1d-wj2Qzz9Q5kH9eGPkEMI_EnPrHJapVPPYvNIMs4w&wallet=&currency=DOGE&key=".$key);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host: digitask.ru" , "upgrade-insecure-requests: 1" , "user-agent: Mozilla/5.0 (Linux; Android 9; Redmi 4 Build/PQ3B.190801.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/76.0.3809.111 Mobile Safari/537.36" , "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3" , "referer: https://digitask.ru/notimer/faucet.php?address=".$crot."&g-recaptcha-response=03AERD8XppO9uNarViHMoKS38zi2rwNzthBrLp81JPKjwQNixzdIwmeVU-c6m-Rhp6oNKPzuvXI64tJjXDjm3Im_fx7sMnwx2s26wkI32YjmKWxHRRaWed3bCC6HffqyML1F3uhxiRCvPtLHkKqJ8ObLn3v4PV5_CAarEhaD5O4NC_1dcN5KurJgHLyc_E7INhsMpwRBO_LIIUvkmwmyKxBi_F8PI4godvyk16Hg22BiRQZak2jJz4hO75RsAW45cQKgVL5yu8woAx7nvhfvGjUfK5f9NlF7OhnboACR1mJmVeOF0rRsshLCng2GqF1yqUUgx8a88fLMSpe16SvznWSmkRnxKBrnWd9JFEC6MjXdQ4_Q2ytfY6KnGb1d-wj2Qzz9Q5kH9eGPkEMI_EnPrHJapVPPYvNIMs4w&wallet=&currency=DOGE&key=".$key."" , "accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7" , "cookie: valet_adress=".$crot."" , "cookie: ft=2447322960" , "cookie: bidswitch_last_time=1583322723789" , ""));
$mbot = curl_exec($ch);
curl_close($ch);
$bale = explode('<div class="alert alert-success">', $mbot);
$bale2 = explode('<a target=',$bale[1]);
$xc = $bale2[0];
//echo $mbot." \n";
//KANXCK
if($xc == true){
echo " \033[1;32m".$x." \033[1;33m[\033[1;35m".date('H:i:s')."\033[1;33m] \e[0m# \033[1;36m".$xc."your account\n";
} 
if($x == "$max"){
break; 
     }
   }
}