<?php
date_default_timezone_set('Asia/Jakarta');
@system("clear");

$star = "22000";
$max = "23459";
$key = "ec9076a9d7b9f98d83633ef9e6fcd7da";
$senxx = "doge";

$urutann = file_get_contents("$senxx");
$yelahh = explode("\n",$urutann);
while(true){
for($x=$star;$x<=$max,$x<count($yelahh);$x++){
$yeah = explode("|",$yelahh[$x]);
$crot = $yeah[0];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://digitask.ru/notimer/faucet.php?address=".$crot."&g-recaptcha-response=03AHaCkAZ-DGlU1Pd98AR4_41prBN_wtuD_rD7Wq_uEftDP1edl3h15quT8m-jYzlKNAPS21seW-99ekQ19bc7ToP0AiTDRKsA_hx0nVdbhd5bSPeuDCrllMgC-L6QP8QxOpWDb7NZG8TIRYItfJBXcVg_D_mPuiDBk4aHSDCZjkL01A_dIyDDhspa8O1v7q3ygZt1qrwYNTDvicB-_kfpGBVuLq5_XVD64XCLvJAgTw6esTglwWAE6CugJy7TLcFDJ7jAnaoFDvya0LV3PZpbhb1qYLLCQKtYBGC4ydF5yDGRb4_3IGFqfDL5SIWYjD9ZoiH-XyZjJTqXMGQiMibp8qCMkQWsR6B_uk7tOBY84I9sD6XhmI7yrhUCSi7Y1xo88apq0SfUG5NQgGoJLKLpyPdRXjETVPNJBQ&wallet=&currency=DOGE&key=".$key);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host: digitask.ru" , "upgrade-insecure-requests: 1" , "user-agent: Mozilla/5.0 (Linux; Android 9; Redmi 4 Build/PQ3B.190801.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/76.0.3809.111 Mobile Safari/537.36" , "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3" , "accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7" , "cookie: valet_adress=".$crot."" , "cookie: ft=61585306551" , "cookie: claimtime=1616965291" , "cookie: address=".$crot."" , "cookie: antibot=3cb4a66d019d133441c30155c616a606"));
$mbot = curl_exec($ch);
curl_close($ch);
$bale = explode('<div class="alert alert-success">', $mbot);
$bale2 = explode('<a target=',$bale[1]);
$xc = $bale2[0];
//echo $mbot." \n";
//exit();
//KANXCK
if($xc == true){
echo " \033[1;32m".$x." \033[1;33m[\033[1;35m".date('H:i:s')."\033[1;33m] \e[0m# \033[1;36m".$xc."your account\n";
	}
if($x == "$max"){
break; 
     }
   }
}